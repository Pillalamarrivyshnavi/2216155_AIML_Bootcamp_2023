def muln(x,y):
    return x*y
def divn(x,y):
    return x/y
x="demonstrates main package"
def main_packagedemo():
    return "main_package demonstration"
import main_package as mp
print(mp.x)
print(mp.main_packagedemo())
print("_______________")

import main_package.sub_pack1 as ms1
print(ms1.sub1)
print(ms1.subpack1)
print("_____________")

from main_package.sub_pack1 import addsub as as1
print(as1.addn(5,5))
print(as1.subn(10,5))

import main_package.sub_pack2 as ms2
print(ms2.sub2)
print(ms2.subpack2())
print("__________________")

from main_package.sub_pack2 import muldiv as md
print(md.muln(3,3))
print(md.divn(10,2))
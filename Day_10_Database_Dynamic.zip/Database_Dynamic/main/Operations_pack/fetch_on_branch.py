import sqlite3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")
def get_onbranch(input_branch):
    records=conn.execute("select * from participants where branch='"+input_branch+"'")
    for i in records:
        print(i)
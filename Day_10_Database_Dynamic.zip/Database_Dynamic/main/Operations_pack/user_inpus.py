import sqlite3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")

def input_data():
    g_id=input("Enter gid")
    name=input("enter name")
    branch=input("enter branch")
    study=input("enter study")
    data={}
    data['g_id']=g_id
    data['name']=name
    data['branch']=branch
    data['study']=study
    #insert into participants values(1063,"vysh","CSE"...)
    conn.execute('''
    insert into participants(g_id,name,branch,study)values(?,?,?,?)
    ''',(data.get("g_id"),data.get("name"),data.get("branch"),data.get("study")))

    conn.commit()
    print("data inserted successfully")
    return data
from main.Operations_pack import user_inpus as u
from main.Operations_pack import fetch_records as f
from main.Operations_pack import fetch_on_branch as b
from main.Operations_pack import update_name as un
while True:

    print('''
        1.Enter Participant details
        2.Fetch the Prtcipant records
        3.Fetch the participants based on branch
        4.Update-name   
        5.exit from app                                                              
        ''' )
    print("Choose any option above")
    ch=int(input())
    if ch==1:
         print("do smthg")
         u.input_data()
    elif ch==2:
         f.get_records()
         print("....")
    elif ch == 3:
         input_branch=input("enter branch")
         b.get_onbranch(input_branch)
         print("....")
    elif ch==4:
         id=int(input("enter gid"))
         new_name=input("enter the new name to be updated")
         un.update(id,new_name)
         print("....")
    else:
        break

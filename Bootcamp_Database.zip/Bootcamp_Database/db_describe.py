import sqlite3

#step 2 & step 3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")
print(conn)

'''
describe tabel_name==>MySql
pragma table_info(table_name)==>sqlite3
'''
#step 4
query = ''' 
       pragma table_info(participants)
        '''
details = conn.execute(query)
print(details)
for i in details:
    print(i)

'''
O/P:
(0, 'G_id', 'INT', 0, None, 1)
(1, 'name', 'TEXT', 1, None, 0)
(2, 'branch', 'TEXT', 1, None, 0)
(3, 'study', 'TEXT', 1, None, 0)
'''
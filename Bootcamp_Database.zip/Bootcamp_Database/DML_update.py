import sqlite3

#step 2 & step 3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")
print(conn)

conn.execute("update participants set name ='Vyshnavi' where G_id=2216155")
conn.commit()
conn.close()
import sqlite3

#step 2 & step 3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")
print(conn)

'''
drop==>deletes entire schema
'''
conn.execute("drop table participants")
import sqlite3

#step 2 & step 3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")
print(conn)

'''
insert into table_name values('' ,'',...)
'''

conn.execute("insert into Participants values(2216155,'vysh','cse','Btech','pv@gmail.com')")
conn.execute("insert into Participants values(22161001,'hasifa','cse','Btech','hasi@gmail.com')")
conn.execute("insert into Participants values(22161018,'rakshu','ece','Btech','rk@gmail.com')")
conn.execute("insert into Participants values(22161013,'rimsha','ece','Btech','rr@gmail.com')")
conn.execute("insert into Participants values(22161042,'pujitha','ece','Btech','pp@gmail.com')")

print(conn.total_changes)
conn.commit()
conn.close()

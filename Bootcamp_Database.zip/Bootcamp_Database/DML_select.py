import sqlite3

#step 2 & step 3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")
print(conn)
records=conn.execute("select *from Participants")
print(records)
for i in records:
    print(i)
conn.commit()
conn.close()

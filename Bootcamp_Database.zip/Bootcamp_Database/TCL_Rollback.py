import sqlite3

#step 2 & step 3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")
print(conn)

conn.execute("rollback")
print(conn.total_changes)
conn.commit()
conn.close()

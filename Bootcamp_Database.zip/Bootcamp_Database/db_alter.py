import sqlite3

#step 2 & step 3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")
print(conn)

'''
alter table table_name add column_name datatype constraints
'''
conn.execute('alter table participants add column mail_id1 text not null')
conn.commit()
conn.close()

''' changing the datatype of already given
alter table table_name rename col old_name to new_name
'''
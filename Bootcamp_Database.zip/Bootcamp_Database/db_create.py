#steps:
'''
1.importing the module
2.create a database
3.establish the connection with db
4.creating a table in db-participants table==>writing the qeries
5.Exceute the query
'''
#step 1
import sqlite3

#step 2 & step 3
"Bootcamp2023.db"
conn = sqlite3.connect("Bootcamp2023.db")

''' 
create table table_name(col_name1 datatype constraint(primary key,not null,unique
..),col2 datatype dtatype constraint,...)
'''
#step 4
query='''create table participants(G_id int primary key,name text not null,branch text not null,study text not null)'''

#step 5
conn.execute(query)

